import java.io.*;
import java.net.*;
import java.nio.*;
import java.util.*;

class UDPServer{
	static long checksumNum=0;
	private static final int BUFFER_SIZE = 1024;
	private static final int PORT = 8080;
	private static int port =0;
	private static DatagramSocket serverSocket = null;
	private static DatagramPacket packet=null;
	private static DatagramSocket socket = null;
	private static DatagramPacket received = null;
	private static InetAddress IPAddress = null;
	private static byte[] sendData = null;
	private static byte[] receiveData = null;
	private static byte[] getCheck = null;
	private static int nReadSize = 0; 
	private static String str = null;
	private static final String filename = "result2.txt";
	
	static long checksum(byte[] buf, int length) {
	    int i = 0;
	    long sum = 0;
	    while (length > 0) {
	        sum += (buf[i++]&0xff) << 8;
	        if ((--length)==0) break;
	        sum += (buf[i++]&0xff);
	        --length;
	    }
	    return (~((sum & 0xFFFF)+(sum >> 16)))&0xFFFF;
	}
	
	static void connection_establishmecnt(){
      	  try {
      		received = new DatagramPacket( receiveData, receiveData.length );
			serverSocket.receive( received );
			receiveData = ByteBuffer.wrap(received.getData( )).array();
      	    if(receiveData[0] == 1)
      		  System.out.println("Client send SYN to server");
      	    sendData = new byte[BUFFER_SIZE];
      	    sendData[0] = receiveData[0];
      	    sendData[1] = (byte)(receiveData[0]);
            IPAddress = received.getAddress();
            port = received.getPort();    
            packet = new DatagramPacket( sendData, sendData.length, IPAddress, port );
            serverSocket.send( packet ); 
            
            received = new DatagramPacket( receiveData, receiveData.length );
      	    serverSocket.receive( received );

        	 // Get the message from the packet
      	    receiveData = ByteBuffer.wrap(received.getData( )).array();
      	  
           if(receiveData[0] == 1 && receiveData[1] == 1){
        	   System.out.println("Client send ACK" + receiveData[1] + " to server");
           }
           System.out.println("Connection - complete");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static int disconnection_establishment() throws IOException{
		receiveData = new byte[BUFFER_SIZE];
        serverSocket.receive(received);
        byte messages = ByteBuffer.wrap(received.getData( )).get(2);
        if(messages==1){
        	receiveData[1] = 1;
        	receiveData[2] = 1;
        	received = new DatagramPacket( receiveData, receiveData.length, IPAddress, port );
        	serverSocket.send( received ); 
        }
        receiveData = new byte[BUFFER_SIZE];
        serverSocket.receive(received);
        return ByteBuffer.wrap(received.getData( )).get(1);
 
	}
	
	static void initSetting() throws SocketException{
		serverSocket = new DatagramSocket(PORT);
	    System.out.println("Waitng.....");
        receiveData = new byte[ BUFFER_SIZE ];
        sendData = new byte[ BUFFER_SIZE ];
	}
	
	static void checkSumIn() throws IOException{
		receiveData = new byte[BUFFER_SIZE];
    	serverSocket.receive(received);
        str = new String(received.getData()).trim();
        nReadSize = received.getLength(); 
        getCheck = new byte[2];
      	receiveData = ByteBuffer.wrap(received.getData( )).array();
      	getCheck[0] = receiveData[4];
      	getCheck[1] = receiveData[5];
      	receiveData[4] = receiveData[5] = 0;
      	checksumNum = checksum(receiveData,BUFFER_SIZE);
      	receiveData[4] = (byte)((checksumNum & 0xFF00) >> 8);
      	receiveData[5] = (byte)((checksumNum & 0x00FF));
	}
	
	public static void main(String[] args) throws IOException {
		
		long fileSize;
	    long totalReadBytes = 0;
        FileOutputStream fos = null; 
        String str = null;
	    initSetting();
        connection_establishmecnt();
        receiveData = new byte[ BUFFER_SIZE ];
        try {
            
            fos = new FileOutputStream(filename);
            received = new DatagramPacket(receiveData, receiveData.length);
            serverSocket.receive(received);
            str = new String(received.getData()).trim();
            
            if (str.equals("start")){
                System.out.println(str);
                received = new DatagramPacket(receiveData, receiveData.length);
                serverSocket.receive(received);
                str = new String(received.getData()).trim();
                fileSize = Long.parseLong(str);
                double startTime = System.currentTimeMillis(); 
                
                while (true) {
                	
                	checkSumIn();
                	
        	      	if(getCheck[0] == receiveData[4] && getCheck[1] == receiveData[5]){
        	      		System.out.println("CheckSum Correct");
    	      		    fos.write(receiveData, 7, BUFFER_SIZE-7);
                        totalReadBytes+=nReadSize;
                        byte messages = ByteBuffer.wrap(received.getData( )).get(3);
                        sendData[3] = (byte)(messages+1);
                        IPAddress = received.getAddress();
                        port = received.getPort();    
                        
                        if( totalReadBytes >= fileSize ){
                        	sendData[2] = 1;
                        }
                        packet = new DatagramPacket( sendData, sendData.length, IPAddress, port );
                        serverSocket.send( packet ); 
                        sendData = new byte[BUFFER_SIZE];
        	      	}
        	      	else{
        	      		System.out.println("CheckSum InCorrect!!");
        	      	}            
                    System.out.println("In progress: " + totalReadBytes + "/"
                            + fileSize + " Byte(s) ("
                            + (totalReadBytes * 100 / fileSize) + " %)");      
                    if(totalReadBytes>=fileSize){      	
                        if(disconnection_establishment()==1){
                        	break;
                        } 
                    }
                }
                
                double endTime = System.currentTimeMillis();
                double diffTime = (endTime - startTime)/ 1000;;
                double transferSpeed = (fileSize / 1000)/ diffTime;
                 
                System.out.println("time: " + diffTime+ " second(s)");
                System.out.println("Average transfer speed: " + transferSpeed + " KB/s");
                System.out.println("File transfer completed");
                fos.close();
                serverSocket.close();
            } 
            else{
                System.out.println("Start Error");
                fos.close();
                serverSocket.close();
            }
        } catch (Exception e) {}
	}
}