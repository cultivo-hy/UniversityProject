import java.io.*;
import java.net.*;
import java.nio.*;

class UDPClient{
	static long checksumNum=0;
	private static final int BUFFER_SIZE = 1024;
	private static final int PORT = 8080;
	private static final String HOSTNAME = "localhost";
	private static final int SYN_NUM = 0;
	private static final int ACK_NUM = 1;
	private static final int FIN_NUM = 2;
	private static final int ASN_NUM = 3;
	private static final int CHK_NUM_F = 4;
	private static final int CHK_NUM_L = 5;
	private static final int DSN_NUM = 6;
	private static DatagramPacket packet=null;
	private static DatagramSocket socket = null;
	private static DatagramPacket received = null;
	private static InetAddress serverAdd = null;
	private static byte[] sendData = null;
	private static byte[] receiveData = null;
	private static String FileName = "C:\\Users\\Administrator\\workspace\\NetworkProject\\src\\1.txt";
	private static File file=null;
	private static long currentTime;
	private static long elapsetime;
	private static long getTime;
	private static long num;
	private static long startTime;
	private static long allStartTime;
	private static boolean isNeedResend = false;
	private static boolean flag_5 = true;
	private static boolean flag_6 = false;
	static void initSetting() throws Exception{
		socket = new DatagramSocket();
		socket.setSoTimeout(30000);
		serverAdd = InetAddress.getByName( HOSTNAME );
		sendData = new byte[ BUFFER_SIZE ];
		receiveData = new byte[ BUFFER_SIZE ];
		file = new File(FileName);
	}
	
	static void initBuf(byte[] list){
		list[SYN_NUM] = 1;
		list[ACK_NUM] = 0;
		list[FIN_NUM] = 0;
		list[ASN_NUM] = 0;
		list[CHK_NUM_F] = (byte)((checksumNum & 0xFF00) >> 8);
		list[CHK_NUM_L] = (byte)((checksumNum & 0x00FF));
		list[DSN_NUM] = 0;
	}
	
	static void connection_establishment() throws IOException{
		try{
			if(sendData[0] == 1){
				packet = new DatagramPacket(sendData, sendData.length, serverAdd, PORT);
				socket.send(packet);
			}
			received = new DatagramPacket(receiveData, receiveData.length);
			socket.receive( received );
			receiveData = ByteBuffer.wrap( received.getData( ) ).array();
			
			if(receiveData[0] == 1 && receiveData[1] == 1){
				System.out.println( "connection - Server sent SYN to client " );
				System.out.println( "connection - Server sent ACK" + receiveData[1] + " to client "  );
				sendData[1] = (byte)(receiveData[1]);
				socket.send( packet );
			}
		} catch( SocketTimeoutException exception ){
			// If we don't get an ack, prepare to resend sequence number
			System.out.println( "Timeout (Sequence Number )" );
		}
	}
	
	static void disconnetion_establishment() throws IOException{
		sendData = new byte[BUFFER_SIZE];
		sendData[2]=1;				
        System.out.println("disconnection - Client send FIN#" + sendData[2]);
        
        packet = new DatagramPacket(sendData, sendData.length, serverAdd, PORT);
        socket.send(packet);
        
        receiveData = new byte[BUFFER_SIZE];
        received = new DatagramPacket(receiveData, receiveData.length);
		socket.receive(received);
		
		byte[] message = ByteBuffer.wrap(received.getData( )).array();
        if(message[1] == 1 && message[2] == 1){
        	 System.out.println("disconnection - Server send ACK#" + message[1]);
        	 System.out.println("disconnection - Server send FIN#" + message[2]);
        }
        
		sendData = new byte[BUFFER_SIZE];
		sendData[1]=1;
        System.out.println("connection - Client send ACK#" + sendData[1]);
        
        packet = new DatagramPacket(sendData, sendData.length, serverAdd, PORT);
        socket.send(packet);
        System.out.println("connection-close");
	}
	
	static long checksum(byte[] buf, int length) {
	    int i = 0;
	    long sum = 0;
	    while (length > 0) {
	        sum += (buf[i++]&0xff) << 8;
	        if ((--length)==0) break;
	        sum += (buf[i++]&0xff);
	        --length;
	    }
	    return (~((sum & 0xFFFF)+(sum >> 16)))&0xFFFF;
	}

	static void communication() throws IOException{
		packet = new DatagramPacket(sendData, BUFFER_SIZE, serverAdd, PORT); // * 	
        System.out.println("Client send ACK#" + sendData[3]);
        socket.send(packet);
	}
	
    public static void main(String args[]) throws Exception{

    	initSetting();
		initBuf(sendData);
		connection_establishment();
		long fileSize = file.length();
 
        try {
            String str = "start";
            packet = new DatagramPacket(str.getBytes(), str.getBytes().length, serverAdd, PORT);
            socket.send(packet);
            FileInputStream fis = new FileInputStream(file);
            int fileRead=0;
            str = String.valueOf(fileSize);
            packet = new DatagramPacket(str.getBytes(), str.getBytes().length, serverAdd, PORT);
            socket.send(packet);
            sendData = new byte[BUFFER_SIZE];
            allStartTime = System.currentTimeMillis();
            startTime= System.nanoTime();

            while (true){
            	currentTime = System.nanoTime();
            	elapsetime = ((currentTime - startTime) / 1000000000);
            	getTime = elapsetime - num * 30;
            	System.out.println("Time : " + getTime + " Sec ");
            	if(!isNeedResend){
	            	fileRead = fis.read(sendData, 7 , BUFFER_SIZE-7);
					if(fileRead == -1) break;
	                checksumNum = checksum(sendData,BUFFER_SIZE);
	                sendData[CHK_NUM_F] = (byte)((checksumNum & 0xFF00) >> 8);
	                sendData[CHK_NUM_L] = (byte)((checksumNum & 0x00FF));
                }
                else{
                	isNeedResend = false;
            		System.out.println("packet will be retransmitted(��Ŷ�� �������մϴ�.)");
	                sendData[CHK_NUM_F] = (byte)((checksumNum & 0xFF00) << 8);
	                sendData[CHK_NUM_L] = (byte)((checksumNum & 0x00FF));
                	packet = new DatagramPacket(sendData, BUFFER_SIZE, serverAdd, PORT);
                	socket.send(packet);
                	sendData = new byte[BUFFER_SIZE];
                	receiveData = new byte[BUFFER_SIZE];
                }
            	
            	if(flag_5 == true && getTime != 0 && (getTime % 5 )== 0){
            		System.out.println("packet loss(��Ŷ�� �Ҿ���Ƚ��ϴ�.)");
            		flag_5 = false;
            		flag_6 = true;
            	}
            	else if(flag_6 == true && getTime != 0 && (getTime % 6 )== 0){
            		sendData[5] = 0;
            		packet = new DatagramPacket(sendData, BUFFER_SIZE, serverAdd, PORT);
            		
            		flag_5 = true;
            		flag_6 = false;
            		System.out.println("packet corrupt(��Ŷ�� ��ġ�� �����ϴ�.)");
            		socket.send(packet);
            	}
            	else{
                	communication();
                	sendData = new byte[BUFFER_SIZE];
                	receiveData = new byte[BUFFER_SIZE];
            	}
            	try{
        	        received = new DatagramPacket(receiveData, receiveData.length);
        			socket.receive( received );	
        			byte message = ByteBuffer.wrap(received.getData( )).get(3);
        	    	System.out.println("Server send ACK#" + message);

            	}catch(Exception ex){
            		isNeedResend = true;
            		num++;
            		if((getTime % 30) == 0){
            			Thread.sleep(500);
                		flag_5 = true;
                		flag_6 = false;
            		}
            		continue;
            	}
            	if(ByteBuffer.wrap(received.getData( )).get(2)== 1)    break;

            }
            
            disconnetion_establishment();
            double endTime = System.currentTimeMillis();
            double diffTime = (endTime - allStartTime)/ 1000;;
            double transferSpeed = (fileSize / 1000)/ diffTime;
           
            System.out.println("time: " + diffTime+ " second(s)");
            System.out.println("Average transfer speed: " + transferSpeed + " KB/s");
            
            Thread.sleep(1000);
            System.out.println("Process Close");
            fis.close();
            socket.close();
  
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
		socket.close();
   	}
}